"""Mission Planner scoring and the Astronaut Assistant (no network: the AI provider is mocked)."""
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from modules import ai_service, assistant  # noqa: E402
from modules import mission_planner as mp  # noqa: E402


def route(key, km, sci, mean_d, p90_d, caution, cells, found=True):
    m = {"distance_km": km, "science_score": sci, "mean_difficulty": mean_d, "p90_difficulty": p90_d,
         "pct_above_caution": caution, "max_slope_deg": 12.0, "pois_visited": 2, "visited": []}
    return SimpleNamespace(key=key, name=f"R{key}", color="#fff", found=found, metrics=m if found else {},
                           cells=cells, message="" if found else "No traversable path.", pros=[], cons=[])


@pytest.fixture()
def routes():
    return [route("A", 10.0, 40, 0.10, 0.20, 0.0, [1]), route("B", 8.0, 50, 0.20, 0.40, 5.0, [2]),
            route("C", 12.0, 80, 0.15, 0.30, 2.0, [3]), route("D", 8.0, 50, 0.20, 0.40, 5.0, [2]),
            route("E", 0, 0, 0, 0, 0, [], found=False)]


def test_scoring_is_weighted_and_deterministic(routes):
    ev = mp.evaluate_routes(routes, mp.ScoringModel(0.5, 0.3, 0.2))
    c = {x.key: x for x in ev.candidates}
    exp_safety = 100 * (1 - (0.5 * 0.15 + 0.3 * 0.30 + 0.2 * 2.0 / 20))
    assert c["C"].criteria["safety"] == pytest.approx(exp_safety)
    assert c["C"].criteria["distance"] == pytest.approx(100 * 8 / 12)
    assert c["C"].score == pytest.approx(0.5 * 80 + 0.3 * exp_safety + 0.2 * 100 * 8 / 12)
    assert ev.recommended.key == "C"
    assert c["D"].duplicate_of == "B" and c["D"].rank is None
    assert not c["E"].eligible and c["E"].exclusions
    # weights matter: distance-only picks the shortest
    assert mp.evaluate_routes(routes, mp.ScoringModel(0, 0, 1)).recommended.key == "B"


def test_max_distance_constraint_and_missing_criteria(routes):
    ev = mp.evaluate_routes(routes, mp.ScoringModel(), mp.MissionConstraints(max_route_km=11))
    assert "C" in [x.key for x in ev.excluded] and ev.recommended.key != "C"
    routes[0].metrics["science_score"] = None
    a = next(x for x in mp.evaluate_routes(routes).candidates if x.key == "A")
    assert a.missing == ["science"] and a.score is not None


def test_explanation_never_claims_safe(routes):
    text = " ".join(mp.explain_recommendation(mp.evaluate_routes(routes))).lower()
    assert "no route is guaranteed safe" in text and "completely safe" not in text


CTX = {"destination": {"name": "Bright Angel", "lat": 18.5, "lon_east": 77.3},
       "destination_science": {"observations": ["Obs [Ref1]"], "interpretations": [], "reported_minerals": [],
                               "water_related_evidence": [], "suggested_objectives": ["Look at layers"],
                               "why_interesting_marscope": ["Catalogued target"], "references": {"Ref1": "x"}},
       "route_evaluation": None, "uncertainties": ["coarse DTM"], "terrain_data": "real"}


def test_offline_fallback_without_key(monkeypatch):
    monkeypatch.setattr(ai_service, "status", lambda: (False, "none", "No key"))
    r = assistant.answer("What should I investigate when I arrive?", [], CTX)
    assert r.mode == "offline" and "Look at layers" in r.text
    r = assistant.answer("Why does Mars have a thin atmosphere?", [], CTX)
    assert "do not answer this" in r.text           # says so instead of inventing an answer


def test_ai_gets_context_and_history(monkeypatch):
    seen = {}

    def fake_chat(system, messages, max_tokens=0):
        seen.update(system=system, messages=messages)
        return "grounded answer"
    monkeypatch.setattr(ai_service, "status", lambda: (True, "Mock", ""))
    monkeypatch.setattr(ai_service, "chat", fake_chat)
    hist = [{"role": "user", "content": "Why go there?"}, {"role": "assistant", "content": "Because..."},
            {"role": "event", "content": "Mission updated"}]
    r = assistant.answer("What should I investigate?", hist, CTX)
    assert r.mode == "ai" and r.text == "grounded answer"
    assert [m["role"] for m in seen["messages"]] == ["user", "assistant", "user"]
    assert "Bright Angel" in seen["messages"][-1]["content"] and "never say" in seen["system"].lower()


def test_ai_failure_falls_back(monkeypatch):
    def boom(*a, **k):
        raise ai_service.AIUnavailable("Could not reach the Anthropic API.")
    monkeypatch.setattr(ai_service, "status", lambda: (True, "Mock", ""))
    monkeypatch.setattr(ai_service, "chat", boom)
    r = assistant.answer("What should I investigate?", [], CTX)
    assert r.mode == "offline" and "unavailable" in r.note


def test_provider_config(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.delenv("ANTHROPIC_AUTH_TOKEN", raising=False)
    monkeypatch.setenv("MARSCOPE_AI_PROVIDER", "nope")
    assert ai_service.status()[0] is False
    monkeypatch.setenv("MARSCOPE_AI_PROVIDER", "anthropic")
    ok, name, why = ai_service.status()
    assert not ok and "ANTHROPIC_API_KEY" in why
