"""Parsers for live NASA/USGS mission layers, tested on small schema-shaped fixtures.

The fixtures below are TEST INPUTS ONLY (made-up values in the documented response
schemas). They are written to a temporary cache directory and never shipped.
"""
import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config  # noqa: E402
from modules import mission_data as md  # noqa: E402
from modules import tiles  # noqa: E402

TRAVERSE = {"type": "FeatureCollection", "features": [
    {"type": "Feature", "properties": {"sol": 2, "length": 120.5},
     "geometry": {"type": "LineString", "coordinates": [[77.451, 18.445, -2569], [77.449, 18.446, -2569]]}},
    {"type": "Feature", "properties": {"sol": 1, "length": 10},
     "geometry": {"type": "LineString", "coordinates": [[10.0, 10.0], [10.1, 10.1]]}},  # outside region
]}
WAYPOINTS = {"type": "FeatureCollection", "features": [
    {"type": "Feature", "properties": {"sol": 5, "site": 3, "drive": 0, "lat": 18.4446, "lon": 77.4507,
                                       "elev_geoid": -2569.1, "dist_km": 0.1, "RMC": "3_0",
                                       "images": [{"url": "Layers/mosaics/N_TEST.jpg"}]},
     "geometry": {"type": "Point", "coordinates": [77.4507, 18.4446]}},
    {"type": "Feature", "properties": {"sol": 9, "site": 4, "drive": 10},
     "geometry": {"type": "Point", "coordinates": [77.30, 18.50]}},
]}
RAW = {"sol": 5, "images": [
    {"imageid": f"N{i}", "camera": {"instrument": cam}, "sample_type": "Full",
     "image_files": {"small": "s.jpg", "medium": "m.jpg", "large": "l.jpg", "full_res": "f.png"}}
    for i, cam in enumerate(["NAVCAM_LEFT"] * 6 + ["MCZ_LEFT"] * 2)]}


@pytest.fixture()
def cache(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "CACHE_DIR", tmp_path)
    monkeypatch.setattr(config, "OFFLINE_MODE", True)   # never touch the network in tests
    for name, data in [("m20_traverse.json", TRAVERSE), ("m20_waypoints.json", WAYPOINTS),
                       ("m20_raw_sol5.json", RAW)]:
        (tmp_path / name).write_text(json.dumps(data))
    return tmp_path


def test_traverse_parsed_clipped_and_sorted(cache):
    segs, status = md.perseverance_traverse()
    assert status == "cache" and len(segs) == 1
    assert segs[0]["sol"] == 2 and segs[0]["coords"][0] == (18.445, 77.451)


def test_waypoints_and_visits(cache):
    wps, _ = md.perseverance_waypoints()
    assert [w["sol"] for w in wps] == [5, 9]
    assert wps[0]["panorama_url"].endswith("Layers/mosaics/N_TEST.jpg")
    near = md.visits_near(18.4447, 77.4508, wps, radius_m=400)
    assert [v["sol"] for v in near] == [5] and near[0]["distance_m"] < 50


def test_raw_images_prefer_variety(cache):
    imgs, _ = md.raw_images_for_sol(5)
    assert imgs[0]["camera"] == "MCZ_LEFT"               # colour context first
    assert sum(i["camera"] == "NAVCAM_LEFT" for i in imgs) == 4


def test_missing_layers_are_unavailable_not_invented(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "CACHE_DIR", tmp_path)
    monkeypatch.setattr(config, "OFFLINE_MODE", True)
    assert md.perseverance_traverse() == ([], "unavailable")
    assert md.raw_images_for_sol(7) == ([], "unavailable")


def test_tile_grid_alignment():
    g, (x0, x1, y0, y1) = tiles.aligned_grid(config.REGION_BOUNDS, 10)
    t = tiles.tile_deg(10)
    assert g.shape == ((y1 - y0 + 1) * tiles.TILE, (x1 - x0 + 1) * tiles.TILE)
    assert g.lon_min <= config.REGION_BOUNDS[0] and abs((g.lon_min + 180) / t - x0) < 1e-9


def test_landing_destination_parsing():
    from modules import landing
    assert landing.parse_coordinates("18.47, 77.40") == (18.47, 77.40)
    assert landing.parse_coordinates("18.47N 77.40E") == (18.47, 77.40)
    assert landing.parse_coordinates("Bright Angel") is None
    inside = lambda la, lo: 18.05 <= la <= 18.8 and 77.1 <= lo <= 78.0  # noqa: E731
    pois = {"Seitah": {"lat": 18.428, "lon": 77.44, "name": "Seitah"}}
    assert landing.resolve_destination("Seitah", pois, inside)[0] == (18.428, 77.44, "Seitah")
    assert landing.resolve_destination("18.47, 77.40", pois, inside)[0] == (18.47, 77.40, "Map point")
    assert landing.resolve_destination("", pois, inside)[1]
    assert "outside" in landing.resolve_destination("10, 20", pois, inside)[1]
    assert "not a known site" in landing.resolve_destination("Olympus Mons", pois, inside)[1]
