"""Integrated workspace: 3D colour map payload, cross-section, discovery evidence, route science, assistant."""
import base64
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config  # noqa: E402
from modules import assistant  # noqa: E402
from modules import data_manager as dm  # noqa: E402
from modules import mission_planner as mp  # noqa: E402
from modules import route_optimizer as ro  # noqa: E402
from modules import science_discovery as sd  # noqa: E402
from modules import terrain3d  # noqa: E402
from modules import terrain_analysis as ta  # noqa: E402
from modules import workspace as wsp  # noqa: E402

POIS = {p["id"]: p for p in sd.pois()}
ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture(scope="module")
def mission():
    ds = dm.load_or_fetch()
    tm = ta.build_terrain_model(ds)
    sm = sd.build_science_model(ds, tm)
    planner = ro.RoutePlanner(tm, sm)
    s, d = POIS[config.DEMO_START_POI], POIS[config.DEMO_DESTINATION_POI]
    routes = ro.plan_all(planner, (s["lat"], s["lon"]), (d["lat"], d["lon"]), ro.Weights(.2, .3, .5), .7)
    return ds, tm, sm, routes


def _dec(b64, dtype):
    return np.frombuffer(base64.b64decode(b64), dtype=dtype)


def test_terrain_payload_layers_match_the_real_grids(mission):
    ds, tm, sm, _ = mission
    d = terrain3d.terrain_data(ds, tm, sm)
    n = d["nx"] * d["ny"]
    s = terrain3d.MESH_STEP
    elev = _dec(d["elev"], "<i2")
    assert elev.size == n and np.allclose(elev.reshape(d["ny"], d["nx"]), np.round(ds.elevation[::s, ::s]), atol=1)
    assert np.array_equal(_dec(d["cls"], np.uint8).reshape(d["ny"], d["nx"]), tm.terrain_class[::s, ::s])
    sci = _dec(d["sci"], np.uint8)
    assert sci.size == n and sci.max() <= 100
    assert _dec(d["slope"], np.uint8).size == n and _dec(d["geo"], np.uint8).size == n
    assert {m["id"] for m in d["modes"]} == {"elevation", "slope", "class", "geology", "science", "imagery"}
    assert d["elev_lo"] < d["elev_hi"] and len(d["legend"]["class"]) == len(ta.TERRAIN_CLASSES)


def test_geology_zones_mark_catalogued_features_only():
    lat = np.array([POIS["delta_front"]["lat"], 18.75])
    lon = np.array([POIS["delta_front"]["lon"], 77.95])
    z = terrain3d.geology_zones(lat, lon)
    delta_idx = [n for n, *_ in terrain3d.GEO_GROUPS].index("Delta / fan sediments") + 1
    assert z[0, 0] == delta_idx        # on the delta front
    assert z[1, 1] == 0                # far corner: not catalogued, left uncoloured


def test_cross_section_is_centred_and_sampled_from_the_dtm(mission):
    ds, tm, sm, _ = mission
    p = POIS["delta_front"]
    sec = terrain3d.cross_section(ds, tm, sm, p["lat"], p["lon"], 90, 6.0)
    assert len(sec["elev"]) > 100 and abs(sec["d_km"][-1] - sec["d_km"][0] - 6.0) < 0.1
    mid = len(sec["elev"]) // 2
    assert abs(sec["lat"][mid] - p["lat"]) < 0.002 and abs(sec["lon"][mid] - p["lon"]) < 0.03
    ref = ta.sample_along(tm.elevation, ds.fine_grid, np.array([sec["lat"][mid]]), np.array([sec["lon"][mid]]))[0]
    assert abs(sec["elev"][mid] - ref) < 1
    assert any(c["name"] == p["name"] for c in sec["crossings"])


def test_scene_contains_routes_pois_and_labels_simulation_inputs(mission):
    _, _, _, routes = mission
    s, d = POIS[config.DEMO_START_POI], POIS[config.DEMO_DESTINATION_POI]
    scn = terrain3d.scene(routes, "B", (s["lat"], s["lon"], s["name"]), (d["lat"], d["lon"], d["name"]),
                          (18.46, 77.42), None)
    assert scn["selected"] == "B" and scn["routes"] and len(scn["pois"]) == len(POIS)
    pts = scn["routes"][0]["pts"]
    assert all(len(q) == 5 for q in pts) and pts[-1][3] >= pts[0][3]
    assert scn["pace"] == config.SIM_PACE_M_PER_SOL and scn["traverse"] is None


def test_component_is_a_build_free_streamlit_component():
    html = (ROOT / "components" / "terrain_explorer" / "index.html").read_text()
    for needle in ("streamlit:componentReady", "streamlit:setComponentValue", "SIMULATED",
                   "not mission telemetry", "prefers-reduced-motion", "Reveal relief", "Tour layers", "Sweep",
                   "timeline", "Follow rover", "Scan"):
        assert needle in html, needle
    assert "fetch(" not in html     # no network calls from the component


def test_evidence_basis_follows_the_catalogue_citations():
    assert wsp.evidence_basis(POIS["floor_crater_north"])[0] == "Unverified"
    assert wsp.evidence_basis(POIS["margin_unit"])[0] == "Orbital detection"
    assert wsp.evidence_basis(POIS["delta_front"])[0] == "Observed in situ + orbit"
    assert wsp.evidence_basis(POIS["seitah"])[0] == "Observed in situ"
    df = wsp.discovery_table(sd.pois())
    assert len(df) == len(POIS) and set(df["Evidence"]) <= {"Unverified", "Orbital detection", "Observed in situ",
                                                            "Observed in situ + orbit", "Published"}


def test_route_story_quotes_catalogue_and_labels_hypotheses(mission):
    ds, tm, sm, routes = mission
    r = next(r for r in routes if r.key == "C" and r.found)
    story = "\n".join(wsp.route_story(r, tm))
    assert "Route C" in story and "Interpretation (hypothesis)" in story and "[" in story
    shares = wsp.route_terrain_shares(r, tm)
    assert abs(sum(shares.values()) - 1) < 1e-6


def test_composition_charts_build(mission):
    ds, tm, sm, _ = mission
    lat, lon = terrain3d.mesh_latlon(ds)
    figs = wsp.composition_figures(tm, terrain3d.geology_zones(lat, lon))
    assert len(figs) == 3 and all(f.data for f in figs)


def test_tile_crop_uses_real_bundled_imagery():
    p = POIS["delta_front"]
    img, src = wsp.tile_crop(p["lat"], p["lon"], 1.5)
    if img is None:
        pytest.skip("map tiles not bundled")
    assert img.ndim == 3 and img.shape[0] > 100 and ("HiRISE" in src or "CTX" in src)


def test_assistant_answers_about_selected_location_and_visualisations(mission):
    ds, tm, sm, _ = mission
    p = POIS["seitah"]
    info = sd.inspect_location(ds, tm, sm, p["lat"], p["lon"])
    ctx = {"uncertainties": [], "terrain_data": "real", "selected_location": {
        "name": p["name"], "lat": p["lat"], "lon_east": p["lon"], **sd.build_fact_sheet(info),
        "why_interesting_marscope": info["why"]}}
    qs = assistant.suggested_questions(ctx)
    assert any("selected location" in q for q in qs) and any("3D colour map" in q for q in qs)
    r = assistant.offline_answer("What is scientifically interesting about the selected location?",
                                 {**ctx, "relevant_catalogue_entries": [], "all_points_of_interest_index": []})
    assert "Séítah" in r.text and "hypotheses" in r.text
    r2 = assistant.offline_answer("How do I read the 3D colour map?", {**ctx, "visualization_guide": assistant.VIS_GUIDE})
    assert "Elevation" in r2.text and "not a geologic map" in r2.text
