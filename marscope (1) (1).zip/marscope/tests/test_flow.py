"""Mission navigation flow: route cards, simulated navigation helpers, guide, 2D/3D payloads."""
import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config  # noqa: E402
from modules import data_manager as dm  # noqa: E402
from modules import flow, guide, mars_map, nav_map, rover_sim, view3d  # noqa: E402
from modules import mission_planner as mp  # noqa: E402
from modules import route_optimizer as ro  # noqa: E402
from modules import science_discovery as sd  # noqa: E402
from modules import terrain_analysis as ta  # noqa: E402

POIS = {p["id"]: p for p in sd.pois()}


@pytest.fixture(scope="module")
def mission():
    ds = dm.load_or_fetch()
    tm = ta.build_terrain_model(ds)
    sm = sd.build_science_model(ds, tm)
    planner = ro.RoutePlanner(tm, sm)
    s, d = POIS[config.DEMO_START_POI], POIS[config.DEMO_DESTINATION_POI]
    routes = ro.plan_all(planner, (s["lat"], s["lon"]), (d["lat"], d["lon"]), ro.Weights(.2, .3, .5), .7)
    ev = mp.evaluate_routes(routes, mp.ScoringModel())
    return ds, tm, sm, routes, ev


def test_default_start_is_perseverance_landing_and_listed_first():
    assert flow.START_DEFAULT_POI == "octavia_butler_landing"
    opts = flow.start_options(sd.pois())
    assert opts[0] == "octavia_butler_landing" and len(opts) == len(POIS)


def test_nearest_poi_snaps_only_close_clicks():
    p = POIS["kodiak"]
    assert flow.nearest_poi(p["lat"] + 0.001, p["lon"], sd.pois())["id"] == "kodiak"
    assert flow.nearest_poi(p["lat"] + 0.05, p["lon"], sd.pois()) is None


def test_routes_valid_requires_matching_signature():
    assert flow.routes_valid(["r"], ("a",), ("a",))
    assert not flow.routes_valid(["r"], ("a",), ("b",))   # endpoint changed -> routes invalid
    assert not flow.routes_valid(None, ("a",), ("a",))


def test_four_cards_with_estimates_and_one_recommendation(mission):
    *_, routes, ev = mission
    cards = flow.card_data(ev, POIS)
    assert [c["key"] for c in cards] == ["A", "B", "C", "D"]
    assert [c["title"] for c in cards] == ["Safest", "Shortest", "Science-focused", "Balanced / custom"]
    assert sum(c["recommended"] for c in cards) == 1
    for c in cards:
        if c["eligible"]:
            assert c["distance_km"] > 0 and c["sols"][0] < c["sols"][1]
            assert c["risk"] in ("Low", "Moderate", "Elevated")
            assert c["explanation"]
        else:
            assert c["duplicate_of"] or c["excluded"]


def test_stops_exclude_endpoints_and_follow_driving_order(mission):
    *_, routes, _ = mission
    for r in routes:
        stops = flow.notable_stops(r, POIS)
        idx = [i for _, _, i in stops]
        assert idx == sorted(idx)
        names = [p["id"] for _, p, _ in stops]
        assert config.DEMO_START_POI not in names and config.DEMO_DESTINATION_POI not in names


def test_navigation_helpers_along_route(mission):
    *_, routes, _ = mission
    r = next(x for x in routes if x.found)
    stops = flow.notable_stops(r, POIS)
    st0 = rover_sim.state_at(r, 0.0, sd.pois())
    d = flow.direction(r, st0.index)
    assert d is not None and 0 <= d["bearing"] < 360 and d["compass"] in flow.COMPASS
    wp = flow.next_waypoint(r, st0.index, stops)
    assert wp["ahead_m"] > 0
    hz = flow.hazard_ahead(r, st0.index)
    assert hz["max_ahead_deg"] >= hz["here_deg"] - 1e-9 and hz["level"] in ("gentle", "caution", "steep")
    end = rover_sim.state_at(r, 1.0, sd.pois())
    assert flow.direction(r, end.index) is None
    assert flow.next_waypoint(r, end.index, stops)["label"] == "Destination"


def test_step_progress_moves_one_sol_and_caps(mission):
    *_, routes, _ = mission
    r = next(x for x in routes if x.found)
    total = r.profile["distance_m"][-1]
    p1 = flow.step_progress(r, 0.0)
    assert abs(p1 * total - config.SIM_PACE_M_PER_SOL) < 1e-6
    assert flow.step_progress(r, 0.999, sols=10) == 1.0


def test_compass_and_bearing():
    assert flow.compass(0) == "N" and flow.compass(91) == "E" and flow.compass(225) == "SW"
    assert abs(flow.bearing_deg(18, 77, 18.1, 77) - 0) < 1e-6
    assert abs(flow.bearing_deg(18, 77, 18, 77.1) - 90) < 0.1


def test_fit_view_zoom_in_range():
    c, z = flow.fit_view([(18.40, 77.40), (18.50, 77.50)])
    assert 7 <= z <= 17 and abs(c[0] - 18.45) < 1e-9


def test_guide_has_ten_steps_with_targets():
    assert guide.N == 10
    assert all(s.view in ("setup", "routes", "navigate") and s.targets for s in guide.STEPS)
    texts = " ".join(s.body for s in guide.STEPS).lower()
    assert "simulated" in texts and "no live rover connection" in texts
    css = guide.highlight_css(guide.STEPS[3])
    assert ".st-key-calc_btn" in css and "prefers-reduced-motion" in css


def test_nav_map_builds_with_symbols_controls_and_bounds(mission):
    ds, tm, sm, routes, ev = mission
    layers = mars_map.render_layers(ds, tm, sm.value)
    r = ev.recommended.route
    s, d = POIS[config.DEMO_START_POI], POIS[config.DEMO_DESTINATION_POI]
    start, dest = (s["lat"], s["lon"], s["name"]), (d["lat"], d["lon"], d["name"])
    m = nav_map.build(ds, layers, routes=routes, selected=r.key, start=start, destination=dest,
                      stops=flow.notable_stops(r, POIS), pois=sd.pois(),
                      show={"imagery", "slope", "hazards", "targets", "route"},
                      route_bounds=nav_map.route_fit_bounds(r, start, dest), rover_control=True)
    html = m.get_root().render()
    assert "route-draw" in html and "Fit route" in html and "Centre on the simulated rover" in html
    assert "maxBounds" in html and "Destination" in html and "aria-label" in html and "prefers-reduced-motion" in html
    fg = nav_map.rover_layer(rover_sim.state_at(r, 0.4, sd.pois()), r)
    host = nav_map.folium.Map(crs="EPSG4326", tiles=None)
    fg.add_to(host)
    assert "SIMULATED" in host.get_root().render()


def test_3d_payload_uses_real_dtm_and_labels(mission):
    ds, _, _, routes, ev = mission
    t = view3d.terrain_payload(ds)
    assert t["nx"] * t["ny"] == len(t["h"]) and t["exag"] == view3d.VERTICAL_EXAGGERATION
    assert t["synthetic"] == ds.is_demonstration
    r = ev.recommended.route
    sc = view3d.scene_payload(r, (18.44, 77.45, "s"), (18.47, 77.40, "d"), flow.notable_stops(r, POIS),
                              rover_sim.state_at(r, 0.5, sd.pois()))
    assert sc["route"]["pts"] and {m["kind"] for m in sc["markers"]} >= {"start", "dest", "rover"}
    page = view3d.html(t, sc, None, "unavailable (test)", intro=True)
    assert "SIMULATED" in page and "three.min.js" in page and "untextured" in page
    json.loads(page.split("var D = ")[1].split(";\n")[0])


def test_three_js_is_bundled_locally():
    assert (config.BASE_DIR / "static" / "vendor" / "three.min.js").exists() if hasattr(config, "BASE_DIR") else \
        (Path(__file__).resolve().parents[1] / "static" / "vendor" / "three.min.js").exists()
