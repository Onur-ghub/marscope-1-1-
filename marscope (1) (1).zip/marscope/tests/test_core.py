"""Core tests: data validity, A* correctness, and that mission weights change the optimisation."""
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config  # noqa: E402
from modules import data_manager as dm  # noqa: E402
from modules import route_optimizer as ro  # noqa: E402
from modules import science_discovery as sd  # noqa: E402
from modules import terrain_analysis as ta  # noqa: E402


@pytest.fixture(scope="module")
def core():
    ds = dm.load_or_fetch()
    tm = ta.build_terrain_model(ds)
    sm = sd.build_science_model(ds, tm)
    return ds, tm, sm, ro.RoutePlanner(tm, sm)


def ll(pid):
    p = sd.poi_by_id(pid)
    return p["lat"], p["lon"]


def test_real_data_loaded_and_valid(core):
    ds = core[0]
    assert ds.status in ("bundled", "cache", "live")
    assert all(ok for _, ok, _ in dm.validate_dataset(ds))
    assert ds.provenance["elevation"]["kind"] == "observation"


def test_pois_inside_region():
    grid = dm.region_grid(config.FINE_RES_DEG)
    for p in sd.pois():
        assert grid.contains(p["lat"], p["lon"]), p["id"]
        for o in p["observations"] + p["interpretations"]:
            assert o["source"] == "MARSCOPE" or o["source"] in sd.load_poi_catalog()["references"]


def test_astar_matches_dijkstra(core):
    planner = core[3]
    from scipy.sparse.csgraph import dijkstra
    w = ro.Weights(0.3, 0.4, 0.3).normalised()
    costs = planner.edge_costs(w)
    s, g = planner.snap(*ll("octavia_butler_landing")), planner.snap(*ll("bright_angel"))
    _, a_cost = planner.astar(s, g, costs, w.distance)
    d = dijkstra(planner.sparse_graph(costs), indices=s[0] * planner.W + s[1])
    assert a_cost == pytest.approx(d[g[0] * planner.W + g[1]], rel=1e-9)


def test_weights_change_the_optimisation(core):
    planner = core[3]
    a, b = ll("octavia_butler_landing"), ll("bright_angel")
    safe = planner.evaluate(planner.plan_point_to_point("x", "safe", "#fff", ro.Weights(0.1, 0.9, 0).normalised(), a, b), a, b)
    short = planner.evaluate(planner.plan_point_to_point("y", "short", "#fff", ro.Weights(1, 0, 0).normalised(), a, b), a, b)
    assert safe.cells != short.cells
    assert short.metrics["distance_km"] < safe.metrics["distance_km"]
    assert safe.metrics["mean_difficulty"] < short.metrics["mean_difficulty"]


def test_science_route_visits_more_pois(core):
    planner = core[3]
    a, b = ll("octavia_butler_landing"), ll("bright_angel")
    routes = {r.key: r for r in ro.plan_all(planner, a, b, ro.Weights(0.25, 0.35, 0.4))}
    assert all(r.found for r in routes.values())
    assert routes["C"].metrics["pois_visited"] >= routes["B"].metrics["pois_visited"]
    assert routes["C"].metrics["science_score"] > routes["B"].metrics["science_score"]
    assert routes["B"].metrics["distance_km"] <= routes["C"].metrics["distance_km"]


def test_synthetic_fallback_is_labelled():
    ds = dm.synthetic_dataset()
    assert ds.is_demonstration
    assert ds.provenance["elevation"]["kind"] == "demonstration"
