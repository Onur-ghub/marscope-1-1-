"""Mission Center: simulation clock, waypoints, stepping, narrative, 3D navigation mode."""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config  # noqa: E402
from modules import data_manager as dm  # noqa: E402
from modules import flow  # noqa: E402
from modules import mission_center as mc  # noqa: E402
from modules import route_optimizer as ro  # noqa: E402
from modules import science_discovery as sd  # noqa: E402
from modules import terrain_analysis as ta  # noqa: E402

POIS = {p["id"]: p for p in sd.pois()}
ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture(scope="module")
def nav():
    ds = dm.load_or_fetch()
    tm = ta.build_terrain_model(ds)
    sm = sd.build_science_model(ds, tm)
    planner = ro.RoutePlanner(tm, sm)
    s, d = POIS[config.DEMO_START_POI], POIS[config.DEMO_DESTINATION_POI]
    start, dest = (s["lat"], s["lon"], s["name"]), (d["lat"], d["lon"], d["name"])
    routes = ro.plan_all(planner, start[:2], dest[:2], ro.Weights(.2, .3, .5), .7)
    r = next(r for r in routes if r.key == "C" and r.found)
    stops = flow.notable_stops(r, POIS)
    return ds, tm, r, stops, mc.waypoints(r, stops, start, dest, sd.pois())


def test_clock_runs_at_the_chosen_speed_and_holds_when_paused():
    pace = config.SIM_PACE_M_PER_SOL
    assert mc.clock_d(100, None, 5, 1e9, 5000) == 100                       # paused: position held
    assert mc.clock_d(0, 10.0, 1, 12.0, 5000) == pytest.approx(2 * pace)    # 2 s at 1x = 2 sols
    assert mc.clock_d(0, 10.0, 10, 12.0, 5000) == pytest.approx(min(5000, 20 * pace))
    assert mc.clock_d(4900, 0.0, 10, 100.0, 5000) == 5000                   # clamped at the destination


def test_waypoints_are_ordered_start_stops_destination(nav):
    _, _, r, stops, wps = nav
    assert wps[0]["kind"] == "start" and wps[-1]["kind"] == "dest" and len(wps) == len(stops) + 2
    assert [w["d"] for w in wps] == sorted(w["d"] for w in wps)
    assert wps[-1]["d"] == pytest.approx(mc.total_m(r)) and wps[0]["poi_id"] == config.DEMO_START_POI


def test_step_forward_and_back_visit_every_waypoint(nav):
    _, _, r, _, wps = nav
    d, seen = 0.0, []
    while d < mc.total_m(r) - 1:
        d = mc.step_target(wps, d, +1)
        seen.append(d)
    assert seen == [w["d"] for w in wps[1:]]
    assert mc.step_target(wps, seen[-1], -1) == wps[-2]["d"] and mc.step_target(wps, 5, -1) == 0.0
    cur, nxt = mc.current_next(wps, wps[1]["d"] + 10)
    assert cur is wps[1] and nxt is wps[2]
    assert mc.current_next(wps, mc.total_m(r))[1] is None


def test_narrative_uses_route_data_and_never_claims_live_telemetry(nav):
    ds, tm, r, stops, wps = nav
    total = mc.total_m(r)
    d = wps[1]["d"] - 400
    cur, nxt = mc.current_next(wps, d)
    hz = flow.hazard_ahead(r, mc.index_at(r, d))
    txt = mc.narrative(mc.PLAYING, "Route C (Science-focused)", d, total, cur, nxt, hz, None)
    assert nxt["name"] in txt and "0.4 km" in txt and mc.terrain_phrase(hz) in txt
    done = mc.narrative(mc.COMPLETED, "Route C", total, total, wps[-1], None, hz, None)
    assert "simulated" in done.lower() and wps[-1]["name"] in done
    for t in (txt, done):
        assert "live" not in t.lower() and "telemetry" not in t.lower()
    assert mc.terrain_phrase({"level": "caution"}) == "moderately steep"
    act = mc.recommended_action(mc.PAUSED, {**hz, "level": "steep"}, nxt, 300)
    assert "Slow down" in act


def test_three_d_component_has_a_navigation_mode_driven_by_the_shared_clock():
    html = (ROOT / "components" / "terrain_explorer" / "index.html").read_text()
    for needle in ("s.controlled", "play.rate", "s.highlight", "body.nav", "navbadge", "no live rover link",
                   "chkFollowNav", "if(!active)return;"):
        assert needle in html, needle
    css = (ROOT / "assets" / "flow.css").read_text()
    for needle in (".st-key-nav_3d_box", ".st-key-view_switch", "st-key-wpt_", "prefers-reduced-motion"):
        assert needle in css, needle


def test_map_workstation_dock_and_switch_are_wired():
    """Right-hand mission panel (Assistant inside it) and the on-map 2D/3D switch on both map screens."""
    from modules import dock
    assert dock.NAV_TABS[0] == "Assistant" and len(dock.NAV_TABS) == 6 and "Routes" in dock.ROUTE_TABS
    src = (ROOT / "modules" / "flow_ui.py").read_text()
    for needle in ('key="routes_3d_box"', "_dock_strip", "dock.chat(", "_view_switch()",
                   "open_assistant", 'x != "Assistant"'):
        assert needle in src, needle
    css = (ROOT / "assets" / "hud.css").read_text()
    for needle in (".st-key-map_row:has(.dock-closed)", ".st-key-routes_3d_box", "hudCount", "prefers-reduced-motion"):
        assert needle in css, needle


def test_compat_translates_width_for_functions_with_kwargs():
    from modules import st_compat
    calls = {}

    def old_chart(fig, use_container_width=False, **kwargs):
        calls.update(use_container_width=use_container_width, kwargs=kwargs)

    st_compat._wrap(old_chart, "plotly_chart")(1, width="stretch", key="k")
    assert calls == {"use_container_width": True, "kwargs": {"key": "k"}}
